---
title: Bangkit Capstone
emoji: 🏃
colorFrom: pink
colorTo: gray
sdk: docker
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
