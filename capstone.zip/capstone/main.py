from fastapi import FastAPI
from pydantic import BaseModel
import tensorflow as tf
import numpy as np

# Load the pre-trained model
loaded_model = tf.keras.models.load_model('mental_health_1.keras')

# Class labels
class_labels = ['Anxiety', 'Normal', 'Depression', 'Suicidal', 'Stress', 'Bipolar', 'Personality disorder']

# Initialize FastAPI app
app = FastAPI()

# Request model for input validation
class PredictionRequest(BaseModel):
    text: str  # Expecting a list of strings as input

# Define the prediction endpoint
@app.post("/predict/")
async def predict_texts(request: PredictionRequest):
    # Convert input texts to tensor

    texts = []
    texts.append(request.text)
    new_texts_tensor = tf.convert_to_tensor(texts)

    # Perform prediction
    predictions = loaded_model.predict(new_texts_tensor)

    # Prepare the response
    response = []
    for pred in predictions:
        predicted_class = np.argmax(pred, axis=-1)
        predicted_label = class_labels[predicted_class]
        response.append({"predicted_class": predicted_label})

    return {"predictions": response[0]}
# Untuk menjalankan server, gunakan perintah berikut di terminal:
# uvicorn main:app --reload

 #uvicorn main:app --host 0.0.0.0 --port 8000